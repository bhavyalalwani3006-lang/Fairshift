'use strict';
const test = require('node:test');
const assert = require('node:assert');
const logic = require('../src/logic');
const auth = require('../src/auth');

const worker = { id: 'W1', sector: 'construction', hourlyRate: 100 };
const shift = (day, startH, endH) => ({
  workerId: 'W1',
  start: `2026-03-${String(day).padStart(2, '0')}T${String(startH).padStart(2, '0')}:00:00.000Z`,
  end: `2026-03-${String(day).padStart(2, '0')}T${String(endH).padStart(2, '0')}:00:00.000Z`,
});

test('splitHours separates overtime beyond standard hours', () => {
  assert.deepStrictEqual(logic.splitHours(10, 8), { regular: 8, overtime: 2 });
  assert.deepStrictEqual(logic.splitHours(6, 8), { regular: 6, overtime: 0 });
});

test('payslip computes base, overtime (2x construction) and PF', () => {
  const p = logic.buildPayslip(worker, [shift(1, 0, 10)], '2026-03');
  assert.strictEqual(p.regularHours, 8);
  assert.strictEqual(p.overtimeHours, 2);
  assert.strictEqual(p.basePay, 800);
  assert.strictEqual(p.overtimePay, 400);
  assert.strictEqual(p.deductions.pf, 96);
  assert.strictEqual(p.net, 1104);
});

test('payslip ignores other months and open shifts', () => {
  const open = { workerId: 'W1', start: '2026-03-02T00:00:00.000Z', end: null };
  const p = logic.buildPayslip(worker, [open, shift(1, 0, 8)], '2026-04');
  assert.strictEqual(p.gross, 0);
});

test('fatigue: flags more than 60 hours in a week', () => {
  const now = new Date('2026-03-08T12:00:00Z').getTime();
  const shifts = [1, 2, 3, 4, 5, 6].map((d) => shift(d + 1, 0, 11));
  const alerts = logic.fatigueAlerts(shifts, now);
  assert.ok(alerts.some((a) => a.type === 'weekly_hours' && a.level === 'high'));
});

test('fatigue: flags 6 consecutive days and short rest', () => {
  const now = new Date('2026-03-10T00:00:00Z').getTime();
  const shifts = [1, 2, 3, 4, 5, 6].map((d) => shift(d, 6, 21));
  const types = logic.fatigueAlerts(shifts, now).map((a) => a.type);
  assert.ok(types.includes('consecutive_days'));
  assert.ok(types.includes('short_rest'));
});

test('fatigue: no alerts for a normal week', () => {
  const now = new Date('2026-03-08T12:00:00Z').getTime();
  const shifts = [2, 3, 4, 5, 6].map((d) => shift(d, 3, 11));
  assert.deepStrictEqual(logic.fatigueAlerts(shifts, now), []);
});

test('attrition risk is explainable and capped at 100', () => {
  const r = logic.attritionRisk({
    alerts: [{ type: 'weekly_hours', level: 'high' }, { type: 'consecutive_days', level: 'high' }],
    openReports: 3, siteAvgRating: 2, absencesLast30: 5,
  });
  assert.strictEqual(r.score, 100);
  assert.strictEqual(r.level, 'high');
  assert.ok(r.reasons.includes('low_site_rating'));
  assert.strictEqual(logic.attritionRisk({ alerts: [], openReports: 0, siteAvgRating: 4, absencesLast30: 0 }).level, 'low');
});

test('PIN hashing verifies correct PIN only; tokens reject tampering', () => {
  const cred = auth.makeCredential('1234');
  assert.ok(auth.verifyPin('1234', cred));
  assert.ok(!auth.verifyPin('1235', cred));
  const token = auth.sign({ id: 'W1', role: 'worker' });
  assert.strictEqual(auth.verify(token).id, 'W1');
  assert.strictEqual(auth.verify(token.slice(0, -2) + 'xx'), null);
});
