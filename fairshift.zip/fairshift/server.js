'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const store = require('./src/store');
const auth = require('./src/auth');
const logic = require('./src/logic');

const PORT = process.env.PORT || 8080; // Cloud Run injects PORT
const PUBLIC = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'",
};

function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, {
    ...SECURITY_HEADERS,
    ...(isObj ? { 'Content-Type': 'application/json' } : {}),
    ...headers,
  });
  res.end(isObj ? JSON.stringify(body) : body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 100 * 1024) {
        reject(new Error('too_large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch {
        reject(new Error('bad_json'));
      }
    });
  });
}

const clean = (v, max = 500) => String(v == null ? '' : v).trim().slice(0, max);
const publicWorker = (w) => ({ id: w.id, name: w.name, role: w.role, sector: w.sector, siteId: w.siteId, lang: w.lang, hourlyRate: w.hourlyRate });

function currentUser(req) {
  const h = req.headers.authorization || '';
  const payload = auth.verify(h.startsWith('Bearer ') ? h.slice(7) : '');
  if (!payload) return null;
  return store.get().workers.find((w) => w.id === payload.id) || null;
}

function workerSummary(db, w) {
  const mine = db.shifts.filter((s) => s.workerId === w.id);
  const alerts = logic.fatigueAlerts(mine);
  const ratings = db.feedback.filter((f) => f.siteId === w.siteId).map((f) => f.rating);
  const siteAvgRating = ratings.length ? ratings.reduce((a, b) => a + b, 0) / ratings.length : null;
  const openReports = db.reports.filter((r) => r.workerId === w.id && r.status !== 'resolved').length;
  const monthAgo = Date.now() - 30 * 24 * 3600 * 1000;
  const days = new Set(mine.filter((s) => new Date(s.start).getTime() > monthAgo).map((s) => s.start.slice(0, 10)));
  const absencesLast30 = Math.max(0, 22 - days.size) > 18 ? 4 : 0; // coarse demo heuristic
  const risk = logic.attritionRisk({ alerts, openReports, siteAvgRating, absencesLast30 });
  return { ...publicWorker(w), alerts, risk };
}

async function handleApi(req, res, url) {
  const db = store.get();
  const route = `${req.method} ${url.pathname}`;

  if (route === 'GET /api/health') return send(res, 200, { ok: true });

  if (route === 'POST /api/login') {
    const { id, pin } = await readBody(req);
    const wid = clean(id, 20).toUpperCase();
    if (auth.throttled(wid)) return send(res, 429, { error: 'too_many_attempts' });
    const w = db.workers.find((x) => x.id === wid);
    if (!w || !auth.verifyPin(clean(pin, 12), w.cred)) {
      auth.recordFailure(wid);
      return send(res, 401, { error: 'invalid_credentials' });
    }
    auth.clearFailures(wid);
    return send(res, 200, { token: auth.sign({ id: w.id, role: w.role }), user: publicWorker(w) });
  }

  const user = currentUser(req);
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const isAdmin = user.role === 'admin';
  const requireAdmin = () => {
    if (!isAdmin) {
      send(res, 403, { error: 'forbidden' });
      return false;
    }
    return true;
  };

  if (route === 'GET /api/me') return send(res, 200, publicWorker(user));

  // ---- Worker: shifts ----
  if (route === 'GET /api/shifts/mine') {
    const shifts = db.shifts.filter((s) => s.workerId === user.id).sort((a, b) => b.start.localeCompare(a.start)).slice(0, 30);
    const cfg = logic.SECTORS[user.sector];
    const open = shifts.find((s) => !s.end) || null;
    return send(res, 200, {
      open,
      stdHours: cfg ? cfg.stdHours : 8,
      shifts: shifts.map((s) => ({ ...s, hours: logic.round2(logic.shiftHours(s)) })),
      alerts: logic.fatigueAlerts(db.shifts.filter((s) => s.workerId === user.id)),
    });
  }

  if (route === 'POST /api/shifts/checkin') {
    if (isAdmin) return send(res, 403, { error: 'forbidden' });
    const { siteCode } = await readBody(req);
    const site = db.sites.find((s) => s.code === clean(siteCode, 40).toUpperCase());
    if (!site || site.id !== user.siteId) return send(res, 400, { error: 'invalid_site_code' });
    if (db.shifts.some((s) => s.workerId === user.id && !s.end)) return send(res, 409, { error: 'already_checked_in' });
    const shift = { id: store.nextId('SH', db.shifts), workerId: user.id, siteId: site.id, start: new Date().toISOString(), end: null };
    db.shifts.push(shift);
    store.save();
    return send(res, 201, shift);
  }

  if (route === 'POST /api/shifts/checkout') {
    const shift = db.shifts.find((s) => s.workerId === user.id && !s.end);
    if (!shift) return send(res, 409, { error: 'not_checked_in' });
    shift.end = new Date().toISOString();
    store.save();
    return send(res, 200, { ...shift, hours: logic.round2(logic.shiftHours(shift)) });
  }

  // ---- Worker: payslip ----
  if (route === 'GET /api/payslip') {
    const month = clean(url.searchParams.get('month') || new Date().toISOString().slice(0, 7), 7);
    if (!/^\d{4}-\d{2}$/.test(month)) return send(res, 400, { error: 'bad_month' });
    const target = isAdmin ? db.workers.find((w) => w.id === url.searchParams.get('workerId')) : user;
    if (!target) return send(res, 404, { error: 'not_found' });
    return send(res, 200, logic.buildPayslip(target, db.shifts, month));
  }

  // ---- Safety reports ----
  if (route === 'POST /api/reports') {
    const body = await readBody(req);
    const text = clean(body.text, 1000);
    if (!text) return send(res, 400, { error: 'text_required' });
    const severity = ['low', 'medium', 'high'].includes(body.severity) ? body.severity : 'medium';
    const now = new Date().toISOString();
    const report = { id: store.nextId('R', db.reports), workerId: user.id, siteId: user.siteId, text, severity, status: 'open', createdAt: now, updatedAt: now };
    db.reports.push(report);
    store.save();
    return send(res, 201, report);
  }

  if (route === 'GET /api/reports/mine') {
    return send(res, 200, db.reports.filter((r) => r.workerId === user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
  }

  if (route === 'GET /api/reports') {
    if (!requireAdmin()) return;
    return send(res, 200, db.reports.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
  }

  if (req.method === 'PATCH' && url.pathname.startsWith('/api/reports/')) {
    if (!requireAdmin()) return;
    const report = db.reports.find((r) => r.id === url.pathname.split('/').pop());
    const { status } = await readBody(req);
    if (!report) return send(res, 404, { error: 'not_found' });
    if (!['open', 'in_progress', 'resolved'].includes(status)) return send(res, 400, { error: 'bad_status' });
    report.status = status;
    report.updatedAt = new Date().toISOString();
    store.save();
    return send(res, 200, report);
  }

  // ---- Anonymous feedback (no worker id is stored) ----
  if (route === 'POST /api/feedback') {
    const { rating, text } = await readBody(req);
    const r = Number(rating);
    if (!Number.isInteger(r) || r < 1 || r > 5) return send(res, 400, { error: 'bad_rating' });
    db.feedback.push({ id: store.nextId('F', db.feedback), siteId: user.siteId, rating: r, text: clean(text, 500), createdAt: new Date().toISOString() });
    store.save();
    return send(res, 201, { ok: true });
  }

  // ---- Skill passport ----
  if (route === 'GET /api/skills/mine') return send(res, 200, db.skills.filter((s) => s.workerId === user.id));

  if (route === 'POST /api/skills') {
    if (!requireAdmin()) return;
    const { workerId, name, level } = await readBody(req);
    if (!db.workers.some((w) => w.id === workerId) || !clean(name)) return send(res, 400, { error: 'bad_input' });
    const skill = { id: store.nextId('K', db.skills), workerId, name: clean(name, 80), level: clean(level || 'Completed', 30), date: new Date().toISOString().slice(0, 10) };
    db.skills.push(skill);
    store.save();
    return send(res, 201, skill);
  }

  // ---- Admin dashboard ----
  if (route === 'GET /api/admin/dashboard') {
    if (!requireAdmin()) return;
    const workers = db.workers.filter((w) => w.role === 'worker').map((w) => workerSummary(db, w));
    const sites = db.sites.map((s) => {
      const ratings = db.feedback.filter((f) => f.siteId === s.id).map((f) => f.rating);
      return {
        ...s,
        sectorLabel: logic.SECTORS[s.sector].label,
        workers: workers.filter((w) => w.siteId === s.id).length,
        checkedInNow: db.shifts.filter((x) => x.siteId === s.id && !x.end).length,
        avgRating: ratings.length ? logic.round2(ratings.reduce((a, b) => a + b, 0) / ratings.length) : null,
        feedback: db.feedback.filter((f) => f.siteId === s.id).slice(-5).reverse(),
      };
    });
    return send(res, 200, {
      totals: {
        workers: workers.length,
        openReports: db.reports.filter((r) => r.status !== 'resolved').length,
        fatigueFlags: workers.filter((w) => w.alerts.length).length,
        highRisk: workers.filter((w) => w.risk.level === 'high').length,
      },
      workers,
      sites,
    });
  }

  return send(res, 404, { error: 'not_found' });
}

function serveStatic(req, res, url) {
  let rel = url.pathname === '/' ? '/index.html' : url.pathname;
  rel = path.normalize(rel).replace(/^(\.\.[/\\])+/, '');
  const file = path.join(PUBLIC, rel);
  if (!file.startsWith(PUBLIC)) return send(res, 403, 'Forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found');
    send(res, 200, data, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (err) {
    const status = err.message === 'too_large' ? 413 : err.message === 'bad_json' ? 400 : 500;
    if (status === 500) console.error(err);
    if (!res.headersSent) send(res, status, { error: err.message === 'too_large' || err.message === 'bad_json' ? err.message : 'server_error' });
  }
});

if (require.main === module) {
  store.get();
  server.listen(PORT, () => console.log(`FairShift running on port ${PORT}`));
}

module.exports = server;
