'use strict';
(function () {
  const $ = (id) => document.getElementById(id);
  let token = null;

  function el(tag, props = {}, ...kids) {
    const n = document.createElement(tag);
    Object.entries(props).forEach(([k, v]) => {
      if (k === 'class') n.className = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    });
    kids.flat().forEach((c) => n.append(c));
    return n;
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      ...opts,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'error'), { status: res.status });
    return data;
  }

  const pill = (level, label) => el('span', { class: `pill ${level}` }, label || level);
  const table = (heads, rows) => el('table', {}, el('thead', {}, el('tr', {}, ...heads.map((h) => el('th', {}, h)))), el('tbody', {}, ...rows));

  async function load() {
    const d = await api('/api/admin/dashboard');
    $('totals').replaceChildren(
      ...[['Workers', d.totals.workers], ['Open safety reports', d.totals.openReports], ['Fatigue flags', d.totals.fatigueFlags], ['High quit risk', d.totals.highRisk]]
        .map(([label, v]) => el('div', { class: 'card stat' }, el('b', {}, String(v)), label)));

    $('sites').replaceChildren(table(['Site', 'Sector', 'Workers', 'On shift now', 'Avg rating', 'Recent anonymous feedback'],
      d.sites.map((s) => el('tr', {}, el('td', {}, s.name), el('td', {}, s.sectorLabel), el('td', {}, String(s.workers)),
        el('td', {}, String(s.checkedInNow)), el('td', {}, s.avgRating == null ? '-' : `${s.avgRating} / 5`),
        el('td', {}, s.feedback.map((f) => `${'★'.repeat(f.rating)} ${f.text}`).join(' | '))))));

    $('workers').replaceChildren(table(['Worker', 'Sector', 'Fatigue alerts', 'Quit risk', 'Why'],
      d.workers.map((w) => el('tr', {}, el('td', {}, `${w.name} (${w.id})`), el('td', {}, w.sector),
        el('td', {}, w.alerts.length ? w.alerts.map((a) => `${a.type.replace(/_/g, ' ')}: ${a.value}`).join(', ') : 'None'),
        el('td', {}, pill(w.risk.level, `${w.risk.level} (${w.risk.score})`)),
        el('td', {}, w.risk.reasons.map((r) => r.replace(/_/g, ' ')).join(', ') || '-')))));

    const reports = await api('/api/reports');
    $('reports').replaceChildren(table(['When', 'Worker', 'Severity', 'Report', 'Status'],
      reports.map((r) => {
        const sel = el('select', { 'aria-label': `Status for report ${r.id}` },
          ...['open', 'in_progress', 'resolved'].map((s) => { const o = el('option', { value: s }, s.replace('_', ' ')); if (s === r.status) o.selected = true; return o; }));
        sel.addEventListener('change', async () => { await api(`/api/reports/${encodeURIComponent(r.id)}`, { method: 'PATCH', body: { status: sel.value } }); load(); });
        return el('tr', {}, el('td', {}, r.createdAt.slice(0, 10)), el('td', {}, r.workerId), el('td', {}, pill(r.severity)), el('td', {}, r.text), el('td', {}, sel));
      })));
  }

  function logout() {
    token = null;
    $('appView').classList.add('hidden'); $('logout').classList.add('hidden'); $('loginView').classList.remove('hidden');
  }

  $('logout').addEventListener('click', logout);
  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('/api/login', { method: 'POST', body: { id: $('aid').value, pin: $('apin').value } });
      if (r.user.role !== 'admin') throw new Error('not_admin');
      token = r.token;
      $('loginView').classList.add('hidden'); $('appView').classList.remove('hidden'); $('logout').classList.remove('hidden');
      await load();
    } catch { $('loginErr').textContent = 'Wrong ID or PIN, or not an admin account.'; }
  });

  $('skillForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('/api/skills', { method: 'POST', body: { workerId: $('skWorker').value.trim().toUpperCase(), name: $('skName').value, level: $('skLevel').value } });
      $('skMsg').textContent = 'Added to skill passport.';
      $('skName').value = '';
    } catch { $('skMsg').textContent = 'Could not add. Check the worker ID.'; }
  });
})();
