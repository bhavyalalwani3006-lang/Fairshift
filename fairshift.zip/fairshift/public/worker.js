'use strict';
// Worker interface. All user text is inserted with textContent (no innerHTML
// with data) to avoid XSS.
(function () {
  const $ = (id) => document.getElementById(id);
  let token = null;
  let user = null;
  let lang = 'en';
  const t = (k) => (window.I18N[lang] && window.I18N[lang][k]) || window.I18N.en[k] || k;

  function el(tag, props = {}, ...kids) {
    const n = document.createElement(tag);
    Object.entries(props).forEach(([k, v]) => {
      if (k === 'class') n.className = v;
      else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v);
    });
    kids.flat().forEach((c) => n.append(c));
    return n;
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      ...opts,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'error'), { status: res.status });
    return data;
  }

  function applyLang() {
    document.documentElement.lang = lang;
    $('appName').textContent = t('appName');
    document.querySelectorAll('[data-t]').forEach((n) => {
      const icon = n.textContent.match(/^\p{Extended_Pictographic}️?\s*/u);
      n.textContent = (icon ? icon[0] : '') + t(n.dataset.t);
    });
  }

  // ---------- Shift ----------
  async function renderShift() {
    const box = $('tab-shift');
    const data = await api('/api/shifts/mine');
    box.replaceChildren();
    const status = el('div', { class: 'card' },
      el('div', { class: 'big-icon', 'aria-hidden': 'true' }, data.open ? '🟢' : '⚪'),
      el('h2', {}, data.open ? t('onShift') : t('offShift')));
    if (data.open) {
      const hrs = (Date.now() - new Date(data.open.start)) / 3600000;
      status.append(el('p', {}, `${t('hoursToday')}: ${hrs.toFixed(1)} ${t('hrs')}`),
        el('button', { class: 'danger', onclick: async () => { await api('/api/shifts/checkout', { method: 'POST' }); renderShift(); } }, '🔴 ' + t('checkOut')));
    } else {
      const input = el('input', { id: 'siteCode', placeholder: 'FS-...', autocapitalize: 'characters' });
      const err = el('p', { role: 'alert', class: 'muted' });
      status.append(el('label', { for: 'siteCode' }, t('siteCode')), input, err,
        el('button', {
          onclick: async () => {
            try { await api('/api/shifts/checkin', { method: 'POST', body: { siteCode: input.value } }); renderShift(); }
            catch (e) { err.textContent = e.message === 'invalid_site_code' ? t('errCode') : t('errGeneric'); }
          },
        }, '🟢 ' + t('checkIn')));
    }
    box.append(status);

    data.alerts.forEach((a) => box.append(el('div', { class: 'alert', role: 'alert' }, `🔋 ${t('fatigue')}: ${t('fatigue_' + a.type)}`)));

    const rows = data.shifts.filter((s) => s.end).slice(0, 7).map((s) =>
      el('tr', {}, el('td', {}, s.start.slice(0, 10)), el('td', {}, `${s.hours} ${t('hrs')}`),
        el('td', {}, s.hours > data.stdHours ? `+${(s.hours - data.stdHours).toFixed(1)} OT` : '')));
    box.append(el('div', { class: 'card' }, el('h3', {}, t('recent')), el('table', {}, ...rows)));
  }

  // ---------- Payslip ----------
  async function renderPay() {
    const box = $('tab-pay');
    const month = new Date().toISOString().slice(0, 7);
    const slipBox = el('div');
    const monthInput = el('input', { id: 'month', type: 'month', value: month });
    async function load() {
      const p = await api(`/api/payslip?month=${encodeURIComponent(monthInput.value)}`);
      const line = (label, val, strong) => el('tr', {}, el('td', {}, strong ? el('b', {}, label) : label), el('td', {}, strong ? el('b', {}, val) : val));
      const inr = (n) => `₹${n.toFixed(2)}`;
      slipBox.replaceChildren(el('table', {},
        line(t('rate'), inr(p.hourlyRate)),
        line(t('regular'), `${p.regularHours} ${t('hrs')}`),
        line(t('overtime'), `${p.overtimeHours} ${t('hrs')} (×${p.otMultiplier})`),
        line(t('basePay'), inr(p.basePay)),
        line(t('otPay'), inr(p.overtimePay)),
        line(t('gross'), inr(p.gross), true),
        line(t('pf'), `- ${inr(p.deductions.pf)}`),
        line(t('net'), inr(p.net), true)));
    }
    monthInput.addEventListener('change', load);
    box.replaceChildren(el('div', { class: 'card' }, el('h2', {}, '🧾 ' + t('payslip')), el('label', { for: 'month' }, t('month')), monthInput, slipBox));
    await load();
  }

  // ---------- Safety (voice or text) ----------
  async function renderSafety() {
    const box = $('tab-safety');
    let severity = 'medium';
    const text = el('textarea', { id: 'hazard', rows: '4', maxlength: '1000' });
    const msg = el('p', { role: 'status' });
    const sevBtns = ['low', 'medium', 'high'].map((s) => {
      const b = el('button', { type: 'button', class: 'secondary', 'aria-pressed': String(s === severity) }, t(s));
      b.addEventListener('click', () => { severity = s; sevBtns.forEach((x, i) => x.setAttribute('aria-pressed', String(['low', 'medium', 'high'][i] === s))); });
      return b;
    });
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const speak = el('button', { type: 'button', class: 'secondary' }, '🎤 ' + t('speak'));
    if (!SR) speak.classList.add('hidden');
    speak.addEventListener('click', () => {
      const rec = new SR();
      rec.lang = t('speech');
      speak.textContent = '🎤 ' + t('listening');
      rec.onresult = (e) => { text.value = (text.value + ' ' + e.results[0][0].transcript).trim(); };
      rec.onend = () => { speak.textContent = '🎤 ' + t('speak'); };
      rec.start();
    });
    const send = el('button', {
      onclick: async () => {
        if (!text.value.trim()) return;
        try { await api('/api/reports', { method: 'POST', body: { text: text.value, severity } }); msg.textContent = t('sent'); text.value = ''; renderSafety(); }
        catch { msg.textContent = t('errGeneric'); }
      },
    }, '📨 ' + t('send'));
    const mine = await api('/api/reports/mine');
    box.replaceChildren(
      el('div', { class: 'card' }, el('h2', {}, '⚠️ ' + t('reportHazard')),
        el('label', { for: 'hazard' }, t('describe')), text, speak,
        el('label', {}, t('severity')), el('div', { class: 'row' }, ...sevBtns), send, msg),
      el('div', { class: 'card' }, el('h3', {}, t('myReports')),
        ...mine.map((r) => el('p', {}, el('span', { class: `pill ${r.status}` }, t(r.status)), ' ', r.text))));
  }

  // ---------- Anonymous feedback ----------
  function renderFeedback() {
    const box = $('tab-voice');
    let rating = 0;
    const msg = el('p', { role: 'status' });
    const comment = el('textarea', { id: 'comment', rows: '3', maxlength: '500' });
    const stars = [1, 2, 3, 4, 5].map((n) => {
      const b = el('button', { type: 'button', 'aria-label': `${n}`, 'aria-pressed': 'false' }, '★');
      b.addEventListener('click', () => { rating = n; stars.forEach((s, i) => s.setAttribute('aria-pressed', String(i < n))); });
      return b;
    });
    box.replaceChildren(el('div', { class: 'card' }, el('h2', {}, '💬 ' + t('feedbackTitle')), el('p', { class: 'muted' }, '🔒 ' + t('feedbackNote')),
      el('label', {}, t('rating')), el('div', { class: 'row stars' }, ...stars),
      el('label', { for: 'comment' }, t('comment')), comment,
      el('button', { onclick: async () => {
        if (!rating) return;
        try { await api('/api/feedback', { method: 'POST', body: { rating, text: comment.value } }); msg.textContent = t('sent'); comment.value = ''; }
        catch { msg.textContent = t('errGeneric'); }
      } }, '📨 ' + t('send')), msg));
  }

  // ---------- Skill passport ----------
  async function renderSkills() {
    const skills = await api('/api/skills/mine');
    $('tab-skills').replaceChildren(el('div', { class: 'card' }, el('h2', {}, '🎓 ' + t('skillsTitle')),
      skills.length ? el('table', {}, ...skills.map((s) => el('tr', {}, el('td', {}, s.name), el('td', {}, s.level), el('td', {}, s.date)))) : el('p', {}, t('noSkills'))));
  }

  const renderers = { shift: renderShift, pay: renderPay, safety: renderSafety, voice: renderFeedback, skills: renderSkills };
  let current = 'shift';
  async function show(tab) {
    current = tab;
    document.querySelectorAll('#tabs button').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === tab)));
    ['shift', 'pay', 'safety', 'voice', 'skills'].forEach((n) => $('tab-' + n).classList.toggle('hidden', n !== tab));
    try { await renderers[tab](); } catch (e) { if (e.status === 401) logout(); }
  }

  function logout() {
    token = null; user = null;
    sessionStorage.removeItem('fs_token');
    $('appView').classList.add('hidden');
    $('loginView').classList.remove('hidden');
  }

  async function enter() {
    $('loginView').classList.add('hidden');
    $('appView').classList.remove('hidden');
    show('shift');
  }

  $('lang').addEventListener('change', (e) => { lang = e.target.value; applyLang(); if (user) show(current); });
  document.querySelectorAll('#tabs button').forEach((b) => b.addEventListener('click', () => show(b.dataset.tab)));
  $('logout').addEventListener('click', logout);
  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const r = await api('/api/login', { method: 'POST', body: { id: $('wid').value, pin: $('pin').value } });
      if (r.user.role !== 'worker') { $('loginErr').textContent = t('errInvalid'); return; }
      token = r.token; user = r.user;
      sessionStorage.setItem('fs_token', token);
      lang = user.lang; $('lang').value = lang; applyLang();
      enter();
    } catch { $('loginErr').textContent = t('errInvalid'); }
  });

  applyLang();
})();
