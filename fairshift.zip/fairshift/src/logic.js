'use strict';
// Pure business logic: overtime, payslips, fatigue alerts, attrition risk.
// Kept free of I/O so it is easy to unit test.

const SECTORS = {
  construction: { label: 'Construction', stdHours: 8, otMultiplier: 2.0, pfRate: 0.12 },
  college: { label: 'College / School', stdHours: 8, otMultiplier: 1.5, pfRate: 0.12 },
  hospital: { label: 'Hospital', stdHours: 8, otMultiplier: 2.0, pfRate: 0.12 },
  factory: { label: 'Factory', stdHours: 8, otMultiplier: 2.0, pfRate: 0.12 },
};

const HOUR = 3600 * 1000;
const round2 = (n) => Math.round(n * 100) / 100;

function shiftHours(shift, now = Date.now()) {
  const end = shift.end ? new Date(shift.end).getTime() : now;
  const start = new Date(shift.start).getTime();
  return Math.max(0, (end - start) / HOUR);
}

// Overtime is counted per shift beyond the sector's standard hours.
function splitHours(hours, stdHours) {
  const regular = Math.min(hours, stdHours);
  const overtime = Math.max(0, hours - stdHours);
  return { regular: round2(regular), overtime: round2(overtime) };
}

function monthKey(iso) {
  return iso.slice(0, 7);
}

function buildPayslip(worker, shifts, month, now = Date.now()) {
  const cfg = SECTORS[worker.sector] || SECTORS.construction;
  const mine = shifts.filter(
    (s) => s.workerId === worker.id && s.end && monthKey(s.start) === month
  );
  let regular = 0;
  let overtime = 0;
  const days = [];
  for (const s of mine) {
    const h = shiftHours(s, now);
    const split = splitHours(h, cfg.stdHours);
    regular += split.regular;
    overtime += split.overtime;
    days.push({ date: s.start.slice(0, 10), hours: round2(h), ...split });
  }
  const basePay = round2(regular * worker.hourlyRate);
  const overtimePay = round2(overtime * worker.hourlyRate * cfg.otMultiplier);
  const gross = round2(basePay + overtimePay);
  const pf = round2(basePay * cfg.pfRate);
  return {
    month,
    workerId: worker.id,
    hourlyRate: worker.hourlyRate,
    otMultiplier: cfg.otMultiplier,
    regularHours: round2(regular),
    overtimeHours: round2(overtime),
    basePay,
    overtimePay,
    gross,
    deductions: { pf },
    net: round2(gross - pf),
    days: days.sort((a, b) => a.date.localeCompare(b.date)),
  };
}

// Fatigue rules: >60h in trailing 7 days, 6+ consecutive working days,
// or less than 10h rest between two shifts.
function fatigueAlerts(workerShifts, now = Date.now()) {
  const alerts = [];
  const sorted = [...workerShifts].sort((a, b) => a.start.localeCompare(b.start));

  const weekAgo = now - 7 * 24 * HOUR;
  const weekHours = sorted
    .filter((s) => new Date(s.start).getTime() >= weekAgo)
    .reduce((sum, s) => sum + shiftHours(s, now), 0);
  if (weekHours > 60) {
    alerts.push({ type: 'weekly_hours', level: 'high', value: round2(weekHours) });
  } else if (weekHours > 48) {
    alerts.push({ type: 'weekly_hours', level: 'medium', value: round2(weekHours) });
  }

  const dayKeys = [...new Set(sorted.map((s) => s.start.slice(0, 10)))].sort();
  let run = 1;
  let maxRun = dayKeys.length ? 1 : 0;
  for (let i = 1; i < dayKeys.length; i++) {
    const diff = (new Date(dayKeys[i]) - new Date(dayKeys[i - 1])) / (24 * HOUR);
    run = diff === 1 ? run + 1 : 1;
    maxRun = Math.max(maxRun, run);
  }
  if (maxRun >= 6) alerts.push({ type: 'consecutive_days', level: 'high', value: maxRun });

  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    if (!prev.end) continue;
    const rest = (new Date(sorted[i].start) - new Date(prev.end)) / HOUR;
    if (rest >= 0 && rest < 10) {
      alerts.push({ type: 'short_rest', level: 'medium', value: round2(rest) });
      break;
    }
  }
  return alerts;
}

// Transparent, explainable heuristic (0-100). Reasons are returned so
// employers can act on them rather than trust a black box.
function attritionRisk({ alerts, openReports, siteAvgRating, absencesLast30 }) {
  let score = 0;
  const reasons = [];
  for (const a of alerts) {
    const pts = a.level === 'high' ? 25 : 12;
    score += pts;
    reasons.push(a.type);
  }
  if (openReports > 0) {
    score += Math.min(20, openReports * 10);
    reasons.push('unresolved_reports');
  }
  if (siteAvgRating !== null && siteAvgRating < 3) {
    score += 20;
    reasons.push('low_site_rating');
  }
  if (absencesLast30 >= 4) {
    score += 15;
    reasons.push('absences');
  }
  score = Math.min(100, score);
  const level = score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low';
  return { score, level, reasons };
}

module.exports = {
  SECTORS,
  shiftHours,
  splitHours,
  buildPayslip,
  fatigueAlerts,
  attritionRisk,
  monthKey,
  round2,
};
