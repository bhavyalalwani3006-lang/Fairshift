'use strict';
const fs = require('fs');
const path = require('path');
const { makeCredential } = require('./auth');

// Simple JSON-file store. On Cloud Run the filesystem is ephemeral, so data
// resets on a new instance and is re-seeded with demo data - fine for a demo.
// For production, swap this module for Firestore / Cloud SQL.
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const FILE = path.join(DATA_DIR, 'db.json');

const iso = (daysAgo, hour, minute = 0) => {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - daysAgo);
  d.setUTCHours(hour, minute, 0, 0);
  return d.toISOString();
};

function seed() {
  // Demo-only PINs. Override the admin PIN with ADMIN_PIN in the environment.
  const adminPin = process.env.ADMIN_PIN || '9999';
  const workers = [
    { id: 'W001', name: 'Murugan S', role: 'worker', sector: 'construction', siteId: 'S1', hourlyRate: 90, lang: 'ta', pin: '1111' },
    { id: 'W002', name: 'Ravi K', role: 'worker', sector: 'construction', siteId: 'S1', hourlyRate: 85, lang: 'hi', pin: '2222' },
    { id: 'W003', name: 'Lakshmi P', role: 'worker', sector: 'college', siteId: 'S2', hourlyRate: 70, lang: 'ta', pin: '3333' },
    { id: 'W004', name: 'Asha D', role: 'worker', sector: 'college', siteId: 'S2', hourlyRate: 72, lang: 'en', pin: '4444' },
    { id: 'A001', name: 'Site Admin', role: 'admin', sector: 'all', siteId: null, hourlyRate: 0, lang: 'en', pin: adminPin },
  ].map(({ pin, ...w }) => ({ ...w, cred: makeCredential(pin) }));

  const sites = [
    { id: 'S1', name: 'Metro Tower Site', sector: 'construction', code: 'FS-S1-GATE' },
    { id: 'S2', name: 'Greenfield College Campus', sector: 'college', code: 'FS-S2-MAIN' },
  ];

  const shifts = [];
  let n = 1;
  // W001: heavy hours -> triggers fatigue alerts. W002-W004: normal patterns.
  for (let d = 1; d <= 7; d++) shifts.push({ id: `SH${n++}`, workerId: 'W001', siteId: 'S1', start: iso(d, 3), end: iso(d, 14) });
  for (let d = 1; d <= 5; d++) shifts.push({ id: `SH${n++}`, workerId: 'W002', siteId: 'S1', start: iso(d, 3), end: iso(d, 11, 30) });
  for (let d = 1; d <= 5; d++) shifts.push({ id: `SH${n++}`, workerId: 'W003', siteId: 'S2', start: iso(d, 4), end: iso(d, 12) });
  for (let d = 1; d <= 4; d++) shifts.push({ id: `SH${n++}`, workerId: 'W004', siteId: 'S2', start: iso(d, 4), end: iso(d, 12) });

  return {
    workers,
    sites,
    shifts,
    reports: [
      { id: 'R1', workerId: 'W002', siteId: 'S1', text: 'Loose scaffolding on level 4', severity: 'high', status: 'open', createdAt: iso(2, 6), updatedAt: iso(2, 6) },
    ],
    feedback: [
      { id: 'F1', siteId: 'S1', rating: 2, text: 'Supervisor shouts a lot', createdAt: iso(3, 8) },
      { id: 'F2', siteId: 'S2', rating: 4, text: 'Good facilities', createdAt: iso(3, 8) },
    ],
    skills: [
      { id: 'K1', workerId: 'W001', name: 'Scaffolding safety training', level: 'Certified', date: iso(40, 0).slice(0, 10) },
      { id: 'K2', workerId: 'W003', name: 'Fire safety drill', level: 'Completed', date: iso(60, 0).slice(0, 10) },
    ],
  };
}

let db = null;

function load() {
  try {
    db = JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    db = seed();
    save();
  }
  return db;
}

function save() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify(db));
  } catch (err) {
    console.error('Could not persist data:', err.message);
  }
}

const get = () => db || load();
const nextId = (prefix, list) => `${prefix}${list.length + 1}-${Date.now().toString(36)}`;

module.exports = { get, save, nextId };
