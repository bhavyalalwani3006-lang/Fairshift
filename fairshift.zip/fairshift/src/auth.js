'use strict';
const crypto = require('crypto');

// Signing secret comes from the environment. If none is set (local dev),
// a random one is generated per process - nothing is hard-coded in the repo.
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const TTL_MS = 12 * 60 * 60 * 1000;

function hashPin(pin, salt) {
  return crypto.scryptSync(String(pin), salt, 32).toString('hex');
}

function makeCredential(pin) {
  const salt = crypto.randomBytes(16).toString('hex');
  return { salt, hash: hashPin(pin, salt) };
}

function verifyPin(pin, cred) {
  const a = Buffer.from(hashPin(pin, cred.salt), 'hex');
  const b = Buffer.from(cred.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function sign(payload) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + TTL_MS })).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verify(token) {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.');
  const expected = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString());
    return data.exp > Date.now() ? data : null;
  } catch {
    return null;
  }
}

// Tiny in-memory login throttle: 5 failures per 10 minutes per id.
const attempts = new Map();
function throttled(id) {
  const rec = attempts.get(id);
  return !!rec && rec.count >= 5 && Date.now() - rec.first < 10 * 60 * 1000;
}
function recordFailure(id) {
  const rec = attempts.get(id);
  if (!rec || Date.now() - rec.first > 10 * 60 * 1000) attempts.set(id, { count: 1, first: Date.now() });
  else rec.count += 1;
}
function clearFailures(id) {
  attempts.delete(id);
}

module.exports = { makeCredential, verifyPin, sign, verify, throttled, recordFailure, clearFailures };
