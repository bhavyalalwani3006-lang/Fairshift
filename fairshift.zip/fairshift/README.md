# FairShift - Decent Work Platform (UN SDG 8)

Fairer, safer, more transparent workplaces. One platform, two interfaces, multiple sectors.

- **Worker app** (`/worker.html`): shift check-in/out with automatic overtime, clear payslips, voice/text hazard reports with status tracking, anonymous feedback, skill passport, fatigue alerts. English / Tamil / Hindi, large touch targets, emoji cues, voice input, runs on low-end phones (no frameworks, ~25 KB of JS).
- **Employer dashboard** (`/admin.html`): site and sector overview, fatigue flags, explainable quit-risk scores, safety-report triage, anonymous feedback summary, skill passport updates.

## Cross-sector use cases
| Sector | Example |
|---|---|
| Construction | Daily-wage workers check in at the site gate code, get 2x overtime automatically, report scaffolding hazards by voice. |
| College / School | Support and facility staff check in at campus code, see 1.5x overtime, rate supervisors anonymously. |
| Hospitals, Factories | Already configured in `src/logic.js` (`SECTORS`): add a site in `src/store.js` and it works. |

## Run locally
```bash
node server.js        # Node 18+, zero dependencies
npm test              # unit tests (node --test)
```
Open http://localhost:8080. Demo logins are on the home page.

## Configuration (environment variables)
| Variable | Purpose |
|---|---|
| `SESSION_SECRET` | Signs login tokens. Random per process if unset. Set it in production. |
| `ADMIN_PIN` | Admin PIN for the seeded admin (default `9999`, demo only). |
| `PORT` | Set automatically by Cloud Run. |

No keys or credentials are stored in the repo.

## Security notes
PINs hashed with scrypt, HMAC-signed expiring tokens, login throttling, role checks on every admin endpoint, input validation and size limits, CSP and security headers, no `innerHTML` with user data. Feedback is stored without any worker identifier.

## Limitations / next steps
Data is a JSON file (resets on Cloud Run cold start). For production, replace `src/store.js` with Firestore or Cloud SQL. QR check-in accepts a typed or scanned code; add a camera scanner and geofencing next.

## Deploy to Google Cloud Run
```bash
gcloud run deploy fairshift --source . --region asia-south1 --allow-unauthenticated
```
